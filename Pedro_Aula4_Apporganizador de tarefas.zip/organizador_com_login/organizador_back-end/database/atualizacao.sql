USE organizador_prototipo;

CREATE TABLE IF NOT EXISTS usuarios (
  id         INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  criado_em  DATE NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias (
  id         INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  nome       VARCHAR(60) NOT NULL,
  cor        VARCHAR(7) NOT NULL DEFAULT '#3347C9',
  CONSTRAINT fk_categorias_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO usuarios (nome, email, senha_hash, criado_em)
SELECT 'Camila', 'camila@exemplo.com', '$2y$10$LGKQbyoFFeZtGVoCgh5auuEMux4Sx0fafG9hFbeCMfsbLwQcwnsAi', CURDATE()
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE email = 'camila@exemplo.com');

SET @s = (SELECT IF(COUNT(*) > 0,
  'ALTER TABLE tarefas MODIFY id INT NOT NULL AUTO_INCREMENT', 'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tarefas'
    AND COLUMN_NAME = 'id' AND COLUMN_TYPE LIKE '%unsigned%');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE tarefas ADD COLUMN usuario_id INT NULL AFTER id', 'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tarefas' AND COLUMN_NAME = 'usuario_id');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE tarefas ADD COLUMN categoria_id INT NULL AFTER usuario_id', 'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tarefas' AND COLUMN_NAME = 'categoria_id');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

UPDATE tarefas
SET usuario_id = (SELECT id FROM usuarios WHERE email = 'camila@exemplo.com')
WHERE id > 0 AND usuario_id IS NULL;

SET @s = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE tarefas ADD CONSTRAINT fk_tarefas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE', 'DO 0')
  FROM information_schema.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'tarefas'
    AND CONSTRAINT_NAME = 'fk_tarefas_usuario' AND CONSTRAINT_TYPE = 'FOREIGN KEY');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @s = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE tarefas ADD CONSTRAINT fk_tarefas_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL', 'DO 0')
  FROM information_schema.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'tarefas'
    AND CONSTRAINT_NAME = 'fk_tarefas_categoria' AND CONSTRAINT_TYPE = 'FOREIGN KEY');
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

CREATE TABLE IF NOT EXISTS subtarefas (
  id        INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  tarefa_id INT NOT NULL,
  titulo    VARCHAR(120) NOT NULL,
  concluida TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT fk_subtarefas_tarefa FOREIGN KEY (tarefa_id) REFERENCES tarefas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO categorias (usuario_id, nome, cor)
SELECT u.id, c.nome, c.cor
FROM usuarios u
JOIN (SELECT 'Faculdade' AS nome, '#3347C9' AS cor
      UNION ALL SELECT 'Trabalho', '#B5300F'
      UNION ALL SELECT 'Pessoal',  '#1F7A4D') c
WHERE u.email = 'camila@exemplo.com'
  AND NOT EXISTS (SELECT 1 FROM categorias WHERE usuario_id = u.id);
