-- Banco separado do protótipo (não mexe no seu banco atual)
CREATE DATABASE IF NOT EXISTS organizador_prototipo
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE organizador_prototipo;

-- Recria as tabelas (banco de protótipo; os dados de exemplo voltam ao importar)
DROP TABLE IF EXISTS subtarefas;
DROP TABLE IF EXISTS tarefas;
DROP TABLE IF EXISTS categorias;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
  id         INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nome       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,   -- hash gerado com password_hash()
  criado_em  DATE NOT NULL
) ENGINE=InnoDB;

CREATE TABLE categorias (
  id         INT  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT  NULL,
  nome       VARCHAR(60) NOT NULL,
  cor        VARCHAR(7) NOT NULL DEFAULT '#3347C9',
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tarefas (
  id           INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  usuario_id   INT NULL,
  categoria_id INT NULL,
  titulo       VARCHAR(120) NOT NULL,
  prioridade   ENUM('alta','media','baixa') NOT NULL DEFAULT 'media',
  data         DATE NOT NULL,
  hora         TIME NULL,
  concluida    TINYINT(1) NOT NULL DEFAULT 0,
  observacoes  VARCHAR(200) NOT NULL DEFAULT '',
  criada_em    DATE NOT NULL,
  FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)   ON DELETE CASCADE,
  FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- (corrigido: era INT UNSIGNED; a chave estrangeira exige o mesmo tipo de tarefas.id)
CREATE TABLE subtarefas (
  id        INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  tarefa_id INT NOT NULL,
  titulo    VARCHAR(120) NOT NULL,
  concluida TINYINT(1) NOT NULL DEFAULT 0,
  FOREIGN KEY (tarefa_id) REFERENCES tarefas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Usuário de teste:  camila@exemplo.com  /  senha: 123456
INSERT INTO usuarios (nome, email, senha_hash, criado_em) VALUES
('Camila', 'camila@exemplo.com', '$2y$10$/33Vf6nQXQ14Cl1ijEeG1.JhheI2foSJAvBzmH1EmGahL0hNRKwPi', CURDATE());

INSERT INTO categorias (usuario_id, nome, cor) VALUES
(1, 'Faculdade', '#3347C9'),
(1, 'Trabalho',  '#B5300F'),
(1, 'Pessoal',   '#1F7A4D');

INSERT INTO tarefas (usuario_id, categoria_id, titulo, prioridade, data, hora, concluida, observacoes, criada_em) VALUES
(1, 1, 'Entregar trabalho de Administração','alta', CURDATE(), '18:00', 0, 'Enviar o PDF pelo portal da faculdade antes do prazo.', DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
(1, 2, 'Turno na loja','media', CURDATE(), '14:00', 0, '', DATE_SUB(CURDATE(), INTERVAL 3 DAY)),
(1, 1, 'Estudar para a prova de Contabilidade','media', CURDATE(), '20:30', 0, 'Capítulos 4 e 5.', DATE_SUB(CURDATE(), INTERVAL 2 DAY)),
(1, 3, 'Ligar para o banco','baixa', CURDATE(), NULL, 1, '', DATE_SUB(CURDATE(), INTERVAL 2 DAY)),
(1, 1, 'Comprar caderno','baixa', CURDATE(), NULL, 1, '', DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
(1, 1, 'Seminário de Marketing','alta', DATE_ADD(CURDATE(), INTERVAL 1 DAY), NULL, 0, '', DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
(1, 3, 'Pagar a mensalidade','media', DATE_ADD(CURDATE(), INTERVAL 1 DAY), NULL, 0, '', DATE_SUB(CURDATE(), INTERVAL 1 DAY));

INSERT INTO subtarefas (tarefa_id, titulo, concluida) VALUES
(1, 'Revisar o texto final', 1),
(1, 'Exportar em PDF', 0),
(1, 'Enviar pelo portal', 0),
(3, 'Ler o capítulo 4', 0),
(3, 'Resolver os exercícios do capítulo 5', 0);
