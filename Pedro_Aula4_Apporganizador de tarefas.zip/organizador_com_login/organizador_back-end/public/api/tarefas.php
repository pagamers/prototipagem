<?php
// Ponto de entrada da API:  GET/POST api/tarefas.php   e   GET/PUT/DELETE api/tarefas.php?id=3
require_once __DIR__ . '/../../config/conexao.php';
require_once __DIR__ . '/../../app/auth.php';
require_once __DIR__ . '/../../app/Controllers/TarefaController.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $usuario = usuario_logado();
    if (!$usuario) {
        http_response_code(401);
        echo json_encode(['erro' => 'Faça login para continuar.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $metodo = $_SERVER['REQUEST_METHOD'];
    $id     = isset($_GET['id']) ? (int) $_GET['id'] : null;
    $corpo  = json_decode(file_get_contents('php://input') ?: '[]', true);
    if (!is_array($corpo)) { $corpo = []; }

    [$status, $dados] = (new TarefaController())->tratar((int) $usuario['id'], $metodo, $id, $corpo);
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro no servidor.', 'detalhe' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
