<?php
// Encerra a sessão e volta para a tela inicial.
require_once __DIR__ . '/../app/auth.php';
iniciar_sessao();
$_SESSION = [];
$c = session_get_cookie_params();
setcookie(session_name(), '', time() - 3600, $c['path'], $c['domain'], $c['secure'], $c['httponly']);
session_destroy();
header('Location: index.php');
exit;
