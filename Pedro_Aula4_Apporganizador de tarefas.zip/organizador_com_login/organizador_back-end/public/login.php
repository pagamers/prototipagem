<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/Models/Usuario.php';

if (usuario_logado()) { header('Location: index.php'); exit; }

$erro  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = (string) ($_POST['senha'] ?? '');

    if ($email === '' || $senha === '') {
        $erro = 'Preencha e-mail e senha.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Informe um e-mail válido.';
    } else {
        try {
            $usuario = Usuario::autenticar($email, $senha);
            if ($usuario) {
                session_regenerate_id(true);
                $_SESSION['usuario'] = $usuario;
                header('Location: index.php');
                exit;
            }
            $erro = 'E-mail ou senha incorretos.';
        } catch (Throwable $e) {
            $erro = erro_banco($e);
        }
    }
}

require __DIR__ . '/../app/Views/login.php';
