<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/Models/Usuario.php';

if (usuario_logado()) { header('Location: index.php'); exit; }

$erro  = '';
$nome  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome   = trim($_POST['nome'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $senha  = (string) ($_POST['senha'] ?? '');
    $senha2 = (string) ($_POST['senha2'] ?? '');

    if (mb_strlen($nome) < 2 || mb_strlen($nome) > 80) {
        $erro = 'Informe seu nome (2 a 80 caracteres).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 120) {
        $erro = 'Informe um e-mail válido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha precisa ter pelo menos 6 caracteres.';
    } elseif ($senha !== $senha2) {
        $erro = 'As senhas não são iguais.';
    } else {
        try {
            if (Usuario::emailExiste($email)) {
                $erro = 'Este e-mail já está cadastrado. Faça login.';
            } else {
                $usuario = Usuario::criar($nome, $email, $senha);
                session_regenerate_id(true);
                $_SESSION['usuario'] = $usuario;
                header('Location: index.php');
                exit;
            }
        } catch (PDOException $e) {
            $erro = $e->getCode() === '23000'
                ? 'Este e-mail já está cadastrado. Faça login.'
                : erro_banco($e);
        } catch (Throwable $e) {
            $erro = erro_banco($e);
        }
    }
}

require __DIR__ . '/../app/Views/cadastro.php';
