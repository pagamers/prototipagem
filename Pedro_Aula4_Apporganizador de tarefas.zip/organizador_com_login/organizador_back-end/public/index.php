<?php
// Ponto de entrada: sem login mostra a pergunta "já tem conta?"; com login abre o app.
require_once __DIR__ . '/../app/auth.php';

if (usuario_logado()) {
    header('Content-Type: text/html; charset=utf-8');
    readfile(__DIR__ . '/../app/Views/app.html');
} else {
    require __DIR__ . '/../app/Views/inicio.php';
}
