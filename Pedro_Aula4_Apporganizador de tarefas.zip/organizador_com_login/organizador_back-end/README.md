# Organizador de tarefas – protótipo com back-end

Front-end (HTML/CSS/JS) + API em PHP (MVC simples) + MySQL (PDO).

## Estrutura
- `public/index.html` – o app (mesmo visual do protótipo)
- `public/api/tarefas.php` – rota da API
- `app/Controllers/TarefaController.php` – validação e respostas
- `app/Models/Tarefa.php` – consultas ao banco
- `config/conexao.php` – conexão PDO
- `database/schema.sql` – cria o banco `organizador_prototipo`, a tabela e dados de exemplo

## Como rodar (XAMPP ou PHP embutido)
1. Inicie o MySQL e importe `database/schema.sql` (phpMyAdmin → Importar, ou `mysql -u root < database/schema.sql`).
2. Se seu MySQL tiver senha, ajuste `config/conexao.php`.
3. Na pasta do projeto: `php -S localhost:8000 -t public`
4. Abra `http://localhost:8000` (use F12 → Ctrl+Shift+M para o modo celular).

## API
| Método | URL | Faz |
|---|---|---|
| GET | `api/tarefas.php` | lista todas |
| POST | `api/tarefas.php` | cria (`title`, `pri`, `date`, `time`, `notes`) |
| PUT | `api/tarefas.php?id=3` | atualiza campos enviados (ex.: `{"done":true}`) |
| DELETE | `api/tarefas.php?id=3` | exclui |

Ainda não há login: todas as tarefas são de um único usuário.
