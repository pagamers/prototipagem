<?php
// Funções de sessão usadas pelas telas e pela API.

// true = mostra o erro técnico do banco nas telas (use false quando tudo estiver funcionando)
const DEPURAR = true;
function iniciar_sessao(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
        session_start();
    }
}

function usuario_logado(): ?array
{
    iniciar_sessao();
    return $_SESSION['usuario'] ?? null;
}

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function erro_banco(Throwable $e): string
{
    return DEPURAR
        ? 'Erro no banco de dados: ' . $e->getMessage()
        : 'Não foi possível acessar o banco de dados. Tente novamente.';
}
