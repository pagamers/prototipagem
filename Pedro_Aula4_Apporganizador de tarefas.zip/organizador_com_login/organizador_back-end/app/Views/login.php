<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Entrar – organizador do dia</title>
<?php require __DIR__ . '/_tema.php'; ?>
<?php require __DIR__ . '/_estilo.php'; ?>
</head>
<body>
<button class="tema" type="button" onclick="alternarTema()" aria-label="Alternar entre modo claro e escuro">Claro / Escuro</button>
<main class="box">
  <div class="logo" aria-hidden="true">✓</div>
  <h1>Entrar</h1>
  <p class="sub">Acesse suas tarefas do dia.</p>

  <form class="card" method="post" action="login.php" novalidate>
    <?php if ($erro): ?><div class="err" role="alert"><?= h($erro) ?></div><?php endif; ?>

    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" value="<?= h($email) ?>" placeholder="seu@email.com" autocomplete="email" required>

    <label for="senha">Senha</label>
    <input type="password" id="senha" name="senha" placeholder="Sua senha" autocomplete="current-password" required>

    <button class="btn p" type="submit">Entrar</button>
  </form>
  <p class="rodape">Ainda não tem conta? <a href="cadastro.php">Cadastre-se</a></p>
  <p class="dica">Teste: camila@exemplo.com · senha 123456</p>
</main>
</body>
</html>
