<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Cadastro – organizador do dia</title>
<?php require __DIR__ . '/_tema.php'; ?>
<?php require __DIR__ . '/_estilo.php'; ?>
</head>
<body>
<button class="tema" type="button" onclick="alternarTema()" aria-label="Alternar entre modo claro e escuro">Claro / Escuro</button>
<main class="box">
  <div class="logo" aria-hidden="true">✓</div>
  <h1>Criar conta</h1>
  <p class="sub">Leva menos de um minuto.</p>

  <form class="card" method="post" action="cadastro.php" novalidate>
    <?php if ($erro): ?><div class="err" role="alert"><?= h($erro) ?></div><?php endif; ?>

    <label for="nome">Nome</label>
    <input type="text" id="nome" name="nome" value="<?= h($nome) ?>" placeholder="Seu nome" autocomplete="name" maxlength="80" required>

    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" value="<?= h($email) ?>" placeholder="seu@email.com" autocomplete="email" maxlength="120" required>

    <label for="senha">Senha</label>
    <input type="password" id="senha" name="senha" placeholder="Mínimo de 6 caracteres" autocomplete="new-password" required>

    <label for="senha2">Confirmar senha</label>
    <input type="password" id="senha2" name="senha2" placeholder="Repita a senha" autocomplete="new-password" required>

    <button class="btn p" type="submit">Cadastrar</button>
  </form>
  <p class="rodape">Já tem conta? <a href="login.php">Entrar</a></p>
</main>
</body>
</html>
