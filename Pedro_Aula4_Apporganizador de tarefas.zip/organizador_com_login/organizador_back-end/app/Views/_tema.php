<script>
(function(){
  try{var t=localStorage.getItem('tema');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}
  window.alternarTema=function(){
    var r=document.documentElement,a=r.getAttribute('data-theme');
    var atual=a||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light');
    var novo=atual==='dark'?'light':'dark';
    r.setAttribute('data-theme',novo);
    try{localStorage.setItem('tema',novo)}catch(e){}
  };
})();
</script>
