<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Bem-vindo – organizador do dia</title>
<?php require __DIR__ . '/_tema.php'; ?>
<?php require __DIR__ . '/_estilo.php'; ?>
</head>
<body>
<button class="tema" type="button" onclick="alternarTema()" aria-label="Alternar entre modo claro e escuro">Claro / Escuro</button>
<main class="box">
  <div class="logo" aria-hidden="true">✓</div>
  <h1>Organizador de tarefas</h1>
  <p class="sub">Planeje o seu dia e não perca nenhum prazo.</p>

  <section class="card">
    <p class="pergunta">Você já tem uma conta?</p>
    <div class="btns">
      <a class="btn p" href="login.php">Sim, quero entrar</a>
      <a class="btn" href="cadastro.php">Não, quero me cadastrar</a>
    </div>
  </section>
</main>
</body>
</html>
