<style>
:root{color-scheme:light;--bg:#f4f5fa;--card:#fff;--ink:#12142b;--mut:#5d6384;--line:#e1e4ee;--pri:#3347c9;--on:#fff;--ring:#b9bed2;--bad:#b5300f;--hb:#fde7e0}
@media(prefers-color-scheme:dark){:root:not([data-theme="light"]){color-scheme:dark;--bg:#10121f;--card:#1a1d31;--ink:#eef0fb;--mut:#a0a6c6;--line:#2b2f4a;--pri:#6a7cf0;--on:#0c0e1c;--ring:#4a5075;--bad:#ff9a7d;--hb:#4a2118}}
:root[data-theme="dark"]{color-scheme:dark;--bg:#10121f;--card:#1a1d31;--ink:#eef0fb;--mut:#a0a6c6;--line:#2b2f4a;--pri:#6a7cf0;--on:#0c0e1c;--ring:#4a5075;--bad:#ff9a7d;--hb:#4a2118}
.tema{position:fixed;top:12px;right:14px;z-index:5;border:1px solid var(--line);background:var(--card);color:var(--mut);border-radius:99px;padding:8px 14px;font:inherit;font-size:13px;font-weight:600;cursor:pointer}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;min-height:100dvh;display:grid;place-items:center;padding:20px;background:var(--bg);color:var(--ink);font-family:"Segoe UI",system-ui,-apple-system,"Noto Sans",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
.box{width:100%;max-width:400px}
.logo{width:56px;height:56px;border-radius:16px;background:var(--pri);color:var(--on);display:grid;place-items:center;font-size:28px;margin-bottom:16px}
h1{margin:0 0 6px;font-size:30px;line-height:1.15;font-weight:700;letter-spacing:-.01em}
.sub{margin:0 0 22px;color:var(--mut);font-size:15px}
.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:20px}
label{display:block;font-size:13.5px;font-weight:700;margin:14px 0 8px}
form label:first-of-type{margin-top:0}
input{width:100%;padding:15px 14px;border-radius:12px;border:1px solid var(--ring);background:var(--card);font:inherit;font-size:16px;color:inherit}
a:focus-visible,input:focus-visible,button:focus-visible{outline:3px solid var(--pri);outline-offset:2px}
.err{background:var(--hb);color:var(--bad);border-radius:12px;padding:12px 14px;font-size:14px;font-weight:600;margin-bottom:14px}
.btn{display:block;width:100%;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:14px;padding:16px;font:inherit;font-size:16px;font-weight:600;text-align:center;text-decoration:none;cursor:pointer}
.btn.p{background:var(--pri);color:var(--on);border-color:var(--pri)}
form .btn{margin-top:20px}
.btns{display:flex;flex-direction:column;gap:12px}
.pergunta{font-size:15px;font-weight:700;margin:0 0 12px}
.rodape{margin:18px 0 0;text-align:center;font-size:14px;color:var(--mut)}
.rodape a{color:var(--pri);font-weight:700}
.dica{margin:14px 0 0;text-align:center;font-size:13px;color:var(--mut)}
</style>
