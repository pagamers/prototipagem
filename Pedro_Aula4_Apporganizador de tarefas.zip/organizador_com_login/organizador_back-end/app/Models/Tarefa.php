<?php
// Model: acesso ao banco (somente consultas preparadas). Cada tarefa pertence a um usuário.
class Tarefa
{
    // Converte uma linha do banco para o formato que o front-end usa.
    private static function paraArray(array $r): array
    {
        return [
            'id'      => (int) $r['id'],
            'title'   => $r['titulo'],
            'pri'     => $r['prioridade'],
            'date'    => $r['data'],
            'time'    => $r['hora'] ? substr($r['hora'], 0, 5) : '',
            'done'    => (bool) $r['concluida'],
            'notes'   => $r['observacoes'],
            'created' => $r['criada_em'],
        ];
    }

    public static function listar(int $uid): array
    {
        $st = conectar()->prepare('SELECT * FROM tarefas WHERE usuario_id = ? ORDER BY data, hora IS NULL, hora, id');
        $st->execute([$uid]);
        return array_map([self::class, 'paraArray'], $st->fetchAll());
    }

    public static function buscar(int $id, int $uid): ?array
    {
        $st = conectar()->prepare('SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?');
        $st->execute([$id, $uid]);
        $r = $st->fetch();
        return $r ? self::paraArray($r) : null;
    }

    public static function criar(int $uid, array $d): int
    {
        $st = conectar()->prepare(
            'INSERT INTO tarefas (usuario_id, titulo, prioridade, data, hora, concluida, observacoes, criada_em)
             VALUES (?, ?, ?, ?, ?, 0, ?, CURDATE())'
        );
        $st->execute([$uid, $d['title'], $d['pri'], $d['date'], $d['time'] ?: null, $d['notes']]);
        return (int) conectar()->lastInsertId();
    }

    // Atualização parcial: só altera os campos enviados.
    public static function atualizar(int $id, int $uid, array $d): void
    {
        $colunas = ['title' => 'titulo', 'pri' => 'prioridade', 'date' => 'data',
                    'time' => 'hora', 'done' => 'concluida', 'notes' => 'observacoes'];
        $sets = [];
        $vals = [];
        foreach ($colunas as $campo => $coluna) {
            if (array_key_exists($campo, $d)) {
                $sets[] = "$coluna = ?";
                $v = $d[$campo];
                if ($campo === 'time') { $v = $v ?: null; }
                if ($campo === 'done') { $v = $v ? 1 : 0; }
                $vals[] = $v;
            }
        }
        if (!$sets) { return; }
        $vals[] = $id;
        $vals[] = $uid;
        conectar()->prepare('UPDATE tarefas SET ' . implode(', ', $sets) . ' WHERE id = ? AND usuario_id = ?')->execute($vals);
    }

    public static function excluir(int $id, int $uid): void
    {
        conectar()->prepare('DELETE FROM tarefas WHERE id = ? AND usuario_id = ?')->execute([$id, $uid]);
    }
}
