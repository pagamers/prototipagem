<?php
// Model: usuários (login e cadastro).
class Usuario
{
    /** Devolve o usuário se e-mail e senha conferem; senão, null. */
    public static function autenticar(string $email, string $senha): ?array
    {
        $st = conectar()->prepare('SELECT id, nome, email, senha_hash FROM usuarios WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        if ($u && password_verify($senha, $u['senha_hash'])) {
            unset($u['senha_hash']);
            return $u;
        }
        return null;
    }

    public static function emailExiste(string $email): bool
    {
        $st = conectar()->prepare('SELECT 1 FROM usuarios WHERE email = ?');
        $st->execute([$email]);
        return (bool) $st->fetchColumn();
    }

    /** Cria o usuário e devolve os dados que vão para a sessão. */
    public static function criar(string $nome, string $email, string $senha): array
    {
        $st = conectar()->prepare('INSERT INTO usuarios (nome, email, senha_hash, criado_em) VALUES (?, ?, ?, CURDATE())');
        $st->execute([$nome, $email, password_hash($senha, PASSWORD_DEFAULT)]);
        return ['id' => (int) conectar()->lastInsertId(), 'nome' => $nome, 'email' => $email];
    }
}
