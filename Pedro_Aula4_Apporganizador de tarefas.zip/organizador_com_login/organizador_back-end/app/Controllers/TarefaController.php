<?php
require_once __DIR__ . '/../Models/Tarefa.php';

// Controller: valida a entrada e decide a resposta (status HTTP + dados).
class TarefaController
{
    // Retorna [status, dados]
    public function tratar(int $uid, string $metodo, ?int $id, array $corpo): array
    {
        switch ($metodo) {
            case 'GET':
                return $id ? $this->um($uid, $id) : [200, Tarefa::listar($uid)];
            case 'POST':
                $erro = $this->validar($corpo, true);
                if ($erro) { return [422, ['erro' => $erro]]; }
                return [201, ['id' => Tarefa::criar($uid, $this->limpar($corpo))]];
            case 'PUT':
                if (!$id || !Tarefa::buscar($id, $uid)) { return [404, ['erro' => 'Tarefa não encontrada']]; }
                $erro = $this->validar($corpo, false);
                if ($erro) { return [422, ['erro' => $erro]]; }
                Tarefa::atualizar($id, $uid, $this->limpar($corpo, false));
                return [200, Tarefa::buscar($id, $uid)];
            case 'DELETE':
                if (!$id || !Tarefa::buscar($id, $uid)) { return [404, ['erro' => 'Tarefa não encontrada']]; }
                Tarefa::excluir($id, $uid);
                return [200, ['ok' => true]];
        }
        return [405, ['erro' => 'Método não permitido']];
    }

    private function um(int $uid, int $id): array
    {
        $t = Tarefa::buscar($id, $uid);
        return $t ? [200, $t] : [404, ['erro' => 'Tarefa não encontrada']];
    }

    private function validar(array $d, bool $completo): ?string
    {
        if ($completo || isset($d['title'])) {
            $t = trim((string) ($d['title'] ?? ''));
            if ($t === '' || mb_strlen($t) > 120) { return 'Título obrigatório (até 120 caracteres).'; }
        }
        if (($completo || isset($d['pri'])) && !in_array($d['pri'] ?? '', ['alta', 'media', 'baixa'], true)) {
            return 'Prioridade inválida.';
        }
        if ($completo || isset($d['date'])) {
            $dt = DateTime::createFromFormat('Y-m-d', (string) ($d['date'] ?? ''));
            if (!$dt || $dt->format('Y-m-d') !== $d['date']) { return 'Data inválida.'; }
            else if ($dt < new DateTime('today')) { return 'Data não pode ser no passado.'; }
            else if ($dt > new DateTime('now + 10 years')) { return 'Data não pode ser em mais de 1 ano.'; }
        }
        if (!empty($d['time']) && !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string) $d['time'])) {
            return 'Horário inválido.';
        }
        if (isset($d['notes']) && mb_strlen((string) $d['notes']) > 200) { return 'Observações muito longas.'; }
        return null;
    }

    private function limpar(array $d, bool $completo = true): array
    {
        $o = [];
        if ($completo || isset($d['title'])) { $o['title'] = trim((string) $d['title']); }
        if ($completo || isset($d['pri']))   { $o['pri']   = $d['pri']; }
        if ($completo || isset($d['date']))  { $o['date']  = $d['date']; }
        if ($completo || array_key_exists('time', $d))  { $o['time']  = $d['time'] ?? ''; }
        if ($completo || array_key_exists('notes', $d)) { $o['notes'] = trim((string) ($d['notes'] ?? '')); }
        if (array_key_exists('done', $d)) { $o['done'] = (bool) $d['done']; }
        return $o;
    }
}
