<?php
// Model: acesso ao banco (somente consultas preparadas).
class Tarefa
{
    // Converte uma linha do banco para o formato que o front-end usa.
    private static function paraArray(array $r): array
    {
        return [
            'id'      => (int) $r['id'],
            'title'   => $r['titulo'],
            'pri'     => $r['prioridade'],
            'date'    => $r['data'],
            'time'    => $r['hora'] ? substr($r['hora'], 0, 5) : '',
            'done'    => (bool) $r['concluida'],
            'notes'   => $r['observacoes'],
            'created' => $r['criada_em'],
        ];
    }

    public static function listar(): array
    {
        $sql = 'SELECT * FROM tarefas ORDER BY data, hora IS NULL, hora, id';
        return array_map([self::class, 'paraArray'], conectar()->query($sql)->fetchAll());
    }

    public static function buscar(int $id): ?array
    {
        $st = conectar()->prepare('SELECT * FROM tarefas WHERE id = ?');
        $st->execute([$id]);
        $r = $st->fetch();
        return $r ? self::paraArray($r) : null;
    }

    public static function criar(array $d): int
    {
        $st = conectar()->prepare(
            'INSERT INTO tarefas (titulo, prioridade, data, hora, concluida, observacoes, criada_em)
             VALUES (?, ?, ?, ?, 0, ?, CURDATE())'
        );
        $st->execute([$d['title'], $d['pri'], $d['date'], $d['time'] ?: null, $d['notes']]);
        return (int) conectar()->lastInsertId();
    }

    // Atualização parcial: só altera os campos enviados.
    public static function atualizar(int $id, array $d): void
    {
        $colunas = ['title' => 'titulo', 'pri' => 'prioridade', 'date' => 'data',
                    'time' => 'hora', 'done' => 'concluida', 'notes' => 'observacoes'];
        $sets = [];
        $vals = [];
        foreach ($colunas as $campo => $coluna) {
            if (array_key_exists($campo, $d)) {
                $sets[] = "$coluna = ?";
                $v = $d[$campo];
                if ($campo === 'time') { $v = $v ?: null; }
                if ($campo === 'done') { $v = $v ? 1 : 0; }
                $vals[] = $v;
            }
        }
        if (!$sets) { return; }
        $vals[] = $id;
        conectar()->prepare('UPDATE tarefas SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($vals);
    }

    public static function excluir(int $id): void
    {
        conectar()->prepare('DELETE FROM tarefas WHERE id = ?')->execute([$id]);
    }
}
