-- Banco separado do protótipo (não mexe no seu banco atual)
CREATE DATABASE IF NOT EXISTS organizador_prototipo
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE organizador_prototipo;

CREATE TABLE IF NOT EXISTS tarefas (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  titulo      VARCHAR(120) NOT NULL,
  prioridade  ENUM('alta','media','baixa') NOT NULL DEFAULT 'media',
  data        DATE NOT NULL,
  hora        TIME NULL,
  concluida   TINYINT(1) NOT NULL DEFAULT 0,
  observacoes VARCHAR(200) NOT NULL DEFAULT '',
  criada_em   DATE NOT NULL
) ENGINE=InnoDB;

-- Dados de exemplo (história da Camila)
INSERT INTO tarefas (titulo, prioridade, data, hora, concluida, observacoes, criada_em) VALUES
('Entregar trabalho de Administração','alta', CURDATE(), '18:00', 0, 'Enviar o PDF pelo portal da faculdade antes do prazo.', DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
('Turno na loja','media', CURDATE(), '14:00', 0, '', DATE_SUB(CURDATE(), INTERVAL 3 DAY)),
('Estudar para a prova de Contabilidade','media', CURDATE(), '20:30', 0, 'Capítulos 4 e 5.', DATE_SUB(CURDATE(), INTERVAL 2 DAY)),
('Ligar para o banco','baixa', CURDATE(), NULL, 1, '', DATE_SUB(CURDATE(), INTERVAL 2 DAY)),
('Comprar caderno','baixa', CURDATE(), NULL, 1, '', DATE_SUB(CURDATE(), INTERVAL 1 DAY)),
('Seminário de Marketing','alta', DATE_ADD(CURDATE(), INTERVAL 1 DAY), NULL, 0, '', DATE_SUB(CURDATE(), INTERVAL 4 DAY)),
('Pagar a mensalidade','media', DATE_ADD(CURDATE(), INTERVAL 1 DAY), NULL, 0, '', DATE_SUB(CURDATE(), INTERVAL 1 DAY));
